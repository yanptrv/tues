package org.elsys.springboottimer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootTimerApplicationTests {

    @Test
    void contextLoads() {
    }

}
