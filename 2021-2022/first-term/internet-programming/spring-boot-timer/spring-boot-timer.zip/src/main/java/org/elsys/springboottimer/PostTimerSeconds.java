package org.elsys.springboottimer;

public record PostTimerSeconds(String id, String name, String totalSeconds) {
}
