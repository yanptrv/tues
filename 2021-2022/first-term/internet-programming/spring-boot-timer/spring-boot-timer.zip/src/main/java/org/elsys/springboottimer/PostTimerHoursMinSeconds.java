package org.elsys.springboottimer;

public record PostTimerHoursMinSeconds(String id, String name, String hours, String minutes, String seconds) {
}
