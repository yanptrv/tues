package org.elsys.springboottimer;

public record PostTimerRecord(String id, String name, String time) {
}
