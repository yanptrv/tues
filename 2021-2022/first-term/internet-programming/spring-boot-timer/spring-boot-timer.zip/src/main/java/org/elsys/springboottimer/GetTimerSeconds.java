package org.elsys.springboottimer;

public record GetTimerSeconds(String id, String name, String totalSeconds, String done) {
}
