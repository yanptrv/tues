package org.elsys.springboottimer;

public record GetTimerRecord(String id, String name, String time, String done) {
}
