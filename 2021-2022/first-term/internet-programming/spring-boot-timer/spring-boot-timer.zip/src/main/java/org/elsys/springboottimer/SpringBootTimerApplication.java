package org.elsys.springboottimer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootTimerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootTimerApplication.class, args);
    }

}
