package org.elsys.springboottimer;

public record GetTimerHoursMinSeconds(String id, String name, String hours, String minutes, String seconds, String done) {
}
