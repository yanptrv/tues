package org.elsys.springbootexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootExamApplicationTests {

    @Test
    void contextLoads() {
    }

}
