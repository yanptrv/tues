package org.elsys.springbootexam;

public record Note(String text) {
}
